# # inheritance 
# class Pet:
#     def __init__ (self,name,age):

#         self.name = name 
#         self.age =age
    

#     def show(self):
#        print(f"I am {self.name} and I am {self.age} years old")

#     def speak(self):
#         print("I dont know what to say")

# class Cat(Pet):
#     def speak(self):
#         print("Meow")

    
# class Dog(Pet):
#     def speak(self):
#         print("Bark")

# class Fish(Pet):

#     pass 

# if __name__ == "__main__":

#     p = Pet("Tim",19)
#     c = Cat("Goten",2)
#     # c.speak()
#     d = Dog("Trunks", 2)
#     # d.speak()

#     f = Fish("larry",2)
#     f.speak()



for i in range(1,11,0.5):
    print(i)
